package com.buscrud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.buscrud.entity.bus;
//import com.buscrud.security.User;

public interface BusRepository extends JpaRepository<bus , String>{
	


}